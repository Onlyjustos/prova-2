#include <stdio.h>
#define max 200
int main(){
    int i;
    char frase[max];
    char comp[max];
    int f;
     int cont = 0;
scanf("%[^\n]%*c", frase);
comp[max]=frase[max];

for(i=0;frase[i]!='\0'; i++){
   cont++;
}
for(i=0;frase[i]!='\0'; i++){
   cont--;
   if(frase[i]==comp[cont]){
    f=0;
   } else {
    f++;
   }
}

if(f>0){
printf("PALINDROMO\n");
} else{
    printf("NAO PALINDROMO \n");
}
    return 0;
}