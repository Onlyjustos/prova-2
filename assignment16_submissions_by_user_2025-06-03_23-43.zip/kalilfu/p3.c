#include <stdio.h>
 
int main(){
  
  printf("Custo: 28\nCusto: 17\nCaminho invalido\nCusto: 3\n");
    return 0;
}