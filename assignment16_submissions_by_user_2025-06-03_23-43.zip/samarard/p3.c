#include <stdio.h>

/**
2 * Função que recebe a matriz de distâncias, uma
3 * string contendo o caminho percorrido e retorna
4 * o custo do caminho dado. Caso o caminho seja invalido,
5 * a função retorna -1.
6 *
7 * @param m Matriz de distâncias
8 * @param p String contendo o caminho a ser percorrido
9 * @return custo do caminho ou -1 caso o caminho seja invalido.
10 */

int main(){
    int m[5][5];
    int n;
    int i, j;
    char k;

    scanf("%d", &n);

    
    

        for (i = 0; i < 5; i++){
            for(j = 0; j < 5; j++){
                scanf("%d", m[i][j]);
        }
        }

        if (n != '-1'){
           
            
        }

 if ("n == -1 "){
        printf ("CAMINHO INVALIDO");
 }
 
    return 0;
}